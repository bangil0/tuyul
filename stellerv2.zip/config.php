<?

$userid = "xxxxxxxxxx";
$cred = "xxxxxxxxxx";