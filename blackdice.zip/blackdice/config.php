<?php
$user_agent = "xxxxx" ;
$username = "xxxxxx" ;
$password = "xxxxxx" ;
?>
