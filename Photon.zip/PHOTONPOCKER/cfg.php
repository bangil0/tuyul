<?php

//MASUKAN UID MILIK KALIAN
$uid = "xxxxxxxx";

//MASUKAN CRED MILIK KALIAN!!
$cred = "xxxxxxxx";
