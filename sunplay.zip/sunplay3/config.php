<?php
$refresh_token = "XXXXXX";
$deviceid = "XXXXXX";