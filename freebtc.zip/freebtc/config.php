<?php
$useragent = "xxxxxx";
$username = "xxxxxxx";
$password = "xxxxxx";
?>
